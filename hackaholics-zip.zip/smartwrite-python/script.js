/* MATRIX BACKGROUND */
const canvas=document.getElementById("matrix");
const ctx=canvas.getContext("2d");
canvas.width=innerWidth;canvas.height=innerHeight;
const letters="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const fontSize=14;
const columns=canvas.width/fontSize;
const drops=Array(Math.floor(columns)).fill(1);

setInterval(()=>{
  ctx.fillStyle="rgba(0,0,0,0.05)";
  ctx.fillRect(0,0,canvas.width,canvas.height);
  ctx.fillStyle="#32c522";
  ctx.font=fontSize+"px monospace";
  drops.forEach((y,i)=>{
    const t=letters[Math.floor(Math.random()*letters.length)];
    ctx.fillText(t,i*fontSize,y*fontSize);
    drops[i]=y*fontSize>canvas.height&&Math.random()>0.975?0:y+1;
  });
},33);

/* CURSOR */
const cursor=document.querySelector(".cursor");
addEventListener("mousemove",e=>{
  cursor.style.left=e.clientX+"px";
  cursor.style.top=e.clientY+"px";
});

/* APP */
const API="http://127.0.0.1:8000";
const inputText=document.getElementById("inputText");
const output=document.getElementById("output");
const stats=document.getElementById("stats");
const suggestBox=document.getElementById("suggestBox");
const suggestText=document.getElementById("suggestText");
const emojiBox=document.getElementById("emojiBox");

let lastSuggestion="";

/* HIGHLIGHT */
function highlight(o,c){
  const os=o.split(" "),cs=c.split(" ");
  return cs.map((w,i)=>w!==os[i]?`<span class="highlight">${w}</span>`:w).join(" ");
}

/* SCORE */
function score(o,c){
  const os=o.split(" "),cs=c.split(" ");
  let ok=0;cs.forEach((w,i)=>{if(w===os[i])ok++});
  return Math.round(ok/cs.length*100);
}

/* EMOJI */
function emojiSuggest(t){
  t=t.toLowerCase();
  if(t.includes("happy"))return"😄 🎉";
  if(t.includes("sad"))return"😢";
  if(t.includes("angry"))return"😡";
  if(t.includes("love"))return"❤️ 😍";
  if(t.includes("work")||t.includes("project"))return"💻 🚀";
  return"🙂";
}

/* AUTO SUGGEST */
let timer=null;
inputText.addEventListener("input",()=>{
  clearTimeout(timer);
  const t=inputText.value.trim();
  if(t.length<10){suggestBox.style.display="none";return;}
  timer=setTimeout(()=>autoSuggest(t),700);
});

async function autoSuggest(text){
  const r=await fetch(API+"/check",{method:"POST",headers:{'Content-Type':'application/json'},body:JSON.stringify({text})});
  const d=await r.json();
  if(d.result){
    lastSuggestion=d.result;
    suggestText.innerText=d.result;
    suggestBox.style.display="block";
  }
}

/* TAB = APPLY SUGGESTION */
inputText.addEventListener("keydown",e=>{
  if(e.key==="Tab" && lastSuggestion){
    e.preventDefault();
    inputText.value=lastSuggestion;
    suggestBox.style.display="none";
  }
});

/* FINAL CHECK */
async function checkText(){
  const t=inputText.value.trim();
  if(!t)return;
  const r=await fetch(API+"/check",{method:"POST",headers:{'Content-Type':'application/json'},body:JSON.stringify({text:t})});
  const d=await r.json();
  output.innerHTML=highlight(t,d.result);
  stats.innerHTML=`Words: ${t.split(/\s+/).length}<br>Score: <b>${score(t,d.result)}%</b>`;
  emojiBox.innerText=emojiSuggest(t);
}
document.addEventListener("DOMContentLoaded", () => {

  const emojiBox = document.getElementById("emojiBox");

  if (!emojiBox) return;

  const emojiMap = {
    "happy": ["😊","😁","😄"],
    "birthday": ["🎂","🎉","🥳","🎈"],
    "love": ["❤️","😍","😘"],
    "sad": ["😢","😞","💔"],
    "congrats": ["🎉","👏","🥳"],
    "good luck": ["🍀","🤞"],
    "party": ["🥳","🎉","🍾"],
    "thanks": ["🙏","😊"],
    "wow": ["😮","🔥","🤯"]
  };

  let lastEmoji = "";

  inputText.addEventListener("input", () => {
    const text = inputText.value.toLowerCase();
    emojiBox.innerHTML = "";
    lastEmoji = "";

    for (let key in emojiMap) {
      if (text.includes(key)) {
        emojiMap[key].forEach(e => {
          const span = document.createElement("span");
          span.innerText = e;
          span.onclick = () => pasteEmoji(e);
          emojiBox.appendChild(span);
          lastEmoji = e;
        });
      }
    }
  });

  document.addEventListener("keydown", e => {
    if (e.key === "Alt" && lastEmoji) {
      pasteEmoji(lastEmoji);
    }
  });

  function pasteEmoji(emoji){
    const start = inputText.selectionStart;
    const end = inputText.selectionEnd;
    const text = inputText.value;

    inputText.value =
      text.substring(0, start) +
      emoji +
      text.substring(end);

    inputText.focus();
    inputText.selectionStart =
    inputText.selectionEnd = start + emoji.length;
  }

});

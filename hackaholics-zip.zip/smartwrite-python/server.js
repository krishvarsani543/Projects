const express=require("express");
const fetch=require("node-fetch");
require("dotenv").config();

const app=express();
app.use(express.json());
app.use(express.static(__dirname));

app.post("/check",async(req,res)=>{
  const text=req.body.text;
  const r=await fetch("https://api.groq.com/openai/v1/chat/completions",{
    method:"POST",
    headers:{
      "Content-Type":"application/json",
      "Authorization":`Bearer ${process.env.GROQ_API_KEY}`
    },
    body:JSON.stringify({
      model:"llama-3.1-8b-instant",
      messages:[
        {role:"system",content:"Fix grammar. Return only corrected sentence."},
        {role:"user",content:text}
      ]
    })
  });
  const d=await r.json();
  res.json({result:d.choices[0].message.content});
});

app.listen(3000,()=>console.log("✅ Server running on 3000"));

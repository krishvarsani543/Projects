from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import requests

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

GROQ_API_KEY = "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"

class TextReq(BaseModel):
    text: str

def groq_call(system_prompt, user_text, temp=0.3, max_tokens=40):
    url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {GROQ_API_KEY}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": "llama-3.1-8b-instant",
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_text}
        ],
        "temperature": temp,
        "max_tokens": max_tokens
    }
    r = requests.post(url, json=payload, headers=headers)
    return r.json()["choices"][0]["message"]["content"]
    {
  "text": "mera grammar galat hai",
  "language": "hi"
}


@app.post("/check")
def check(req: TextReq):
    result = groq_call(
        "Fix grammar and spelling. Return ONLY corrected text.",
        req.text,
        0.2,
        80
    )
    return {"result": result}

@app.post("/suggest")
def suggest(req: TextReq):
    suggestion = groq_call(
        "Continue the sentence naturally. Return ONLY the next words.",
        req.text,
        0.6,
        25
    )
    return {"suggestion": suggestion}
